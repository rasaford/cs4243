Please use the anaconda(64-Bit Graphical Installer) (python>=3.5)https://www.anaconda.com/distribution/, download the version based on your system. 
Then you can use the jupyter to run the ipynb file.
  
You may need to install these package
opencv-python
sklearn
numpy


Please implement the required functions in 'Segmentation_method.py' and call them in 'Segmentation.ipynb' to debug.
Note that the jupyter file 'Segmentation.ipynb' and the samples in 'outputs/' are used for debugging.
We will use hold-out images to test your code implemented in Segmentation_method.py. 
###########################################
ASSIGNMENT2
│  Segmentation.ipynb
│  README.txt
│  requirements.txt
│  Segmentation_method.py
│
│  
├─inputs
│      003.png
├─test
│      
└─outputs

##############################################
This assignment is due on 12/09/2019 23:59. Please zip this folder and name it your_student_ID.zip
e.g., A0186989W.zip, and submit it via LumiNUS LAB1_submissions
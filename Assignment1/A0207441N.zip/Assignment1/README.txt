This assignment is due on 29/08/2019 23:59. Please zip this folder and name it your_student_ID.zip
e.g., A0186989W.zip, and submit it via LumiNUS LAB1_submissions
###########################################
ASSIGNMENT1
│  assign1.ipynb
│  README.txt
│  requirements.txt
│  transform.py
│
│  
├─inputs
│      airport.jpg
│      
└─outputs
        guassian_kernel_sample.npy
        image_down_sample.npy
        image_filter_faster_sample.npy
        image_filter_fast_sample.npy
        image_filter_sample.npy
        image_grey_sample.npy
        image_resize_sample.npy
        kernel_rotate_sample.npy
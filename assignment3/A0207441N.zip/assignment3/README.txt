# Instruction for students

Please unzip the file, create a new virtual environment and install all requirements with `pip install -r requirements.txt`. You are required to finish `assignment3.ipynb` by successfully (1) running all of the segments, (2) producing results and (3) answering all of the questions. To produce results, you need to finish the code segments in `image_stitching.py`. Refer to the notebook and the python file for more assignment and submission guidelines.
